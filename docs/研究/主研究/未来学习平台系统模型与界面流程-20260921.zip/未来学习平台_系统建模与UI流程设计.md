# 未来学习平台系统建模与 UI 流程设计

> 版本：V1.0  
> 目标：将角色、用例、系统组件、数据实体、核心类、页面原型和 UI 流串联为一套可追踪的设计成果。  
> 阅读方式：先看第 1 节统一编号，再按“用例图 → UML 组件/状态图 → ER 图 → 类图 → UI 页面 → UI 流”阅读。

## 1. 统一编号与追踪矩阵

### 1.1 角色编号

| 编号 | 角色 | 权限边界 |
|---|---|---|
| A-01 | 学生 | 访问本人课程、项目、计划、资源、测试、评价、预测和历史记录；确认或拒绝计划变更 |
| A-02 | 教师/助教 | 查看所授班级学情摘要与干预证据；复核 AI 建议；审核资源和题目；不能直接改写学生正式计划 |
| A-03 | 管理员 | 维护课程、知识库、Agent、Prompt、Trigger、权限和系统配置；关键操作写入审计日志 |
| A-04 | 系统/Agent | 仅按任务最小必要范围读取数据，通过 Harness、Skill 和服务接口完成任务 |

### 1.2 用例—功能—页面—流程—数据对应表

| 用例 | 功能依据 | 主要执行者 | 对应 UI | UI 流 | 核心数据实体 |
|---|---|---|---|---|---|
| UC-01 登录与学习档案 | FR-01、FR-08 | 身份服务、学伴 | UI-01、UI-02 | F-01 | Student、Enrollment、StudentProfile |
| UC-02 创建/确认学习计划 | FR-03、T02～T04 | 学伴、规划 Agent、确认服务 | UI-02、UI-03 | F-01 | LearningPlan、LearningTask、Confirmation |
| UC-03 开放项目与里程碑 | P11、V2.0 7.7 | 学伴、规划 Agent | UI-02、UI-03 | F-01、F-02 | Project、Milestone、Artifact、LearningTask |
| UC-04 获取/生成/推荐资源 | FR-04～FR-06 | 推荐 Agent、资源 Agent | UI-04 | F-02 | Resource、ResourceKnowledge、ResourceUse、Recommendation |
| UC-05 困难触发与分层支架 | P5、T06、T07 | Trigger、Tutor Skill、推荐 Agent | UI-02、UI-04、UI-05 | F-03 | LearningEvent、Intervention、ResourceUse |
| UC-06 阶段测试与作答 | FR-07、T05 | 测试 Agent | UI-05 | F-04 | Test、Question、TestItem、TestAttempt、AnswerRecord |
| UC-07 查看学情与反思 | FR-09、P12、P13 | 评价 Agent、Student Model、Reflection Service | UI-06 | F-04 | Evaluation、KnowledgeState、Reflection |
| UC-08 动态重规划 | FR-10、FR-11、T08～T10 | Trigger、预测 Agent、规划 Agent、确认服务 | UI-06、UI-07、UI-03 | F-05 | Prediction、Intervention、Confirmation、PlanVersion |
| UC-09 查看历史/设置学伴 | FR-08、FR-12 | 学伴、数据服务 | UI-08、UI-09 | — | Dialogue、LearningEvent、CompanionPreference |
| UC-10 班级总览与学生钻取 | 补充说明 4.1、4.2 | 教师 | UI-10、UI-11 | F-06 | Enrollment、Evaluation、Prediction、Intervention |
| UC-11 复核干预/人工跟进 | 补充说明 4.2 | 教师 | UI-11 | F-06 | Intervention、TeacherFollowUp、AuditLog |
| UC-12 审核资源与题目 | 补充说明 4.3 | 教师 | UI-11 | F-06 | Resource、Question、ReviewRecord、Version |
| UC-13 课程与知识库治理 | 补充说明 4.4 | 管理员 | UI-12 | F-07 | Course、Syllabus、KnowledgePoint、Resource、Version |
| UC-14 Agent/Prompt/Trigger 配置 | 补充说明 4.5、4.6 | 管理员 | UI-12 | F-07 | AgentConfig、PromptVersion、TriggerRule |
| UC-15 监控、权限与审计 | 补充说明 4.7 | 管理员 | UI-12 | F-07 | AgentRunLog、ModelCallLog、AuditLog、RolePermission |

## 2. 用例图

![D-01 未来学习平台用例图](images/D-01_用例图.png)

### 2.1 Mermaid 源码

```mermaid
flowchart LR
    STU(["A-01 学生"])
    TEA(["A-02 教师/助教"])
    ADM(["A-03 管理员"])

    subgraph SYS["未来学习平台"]
        UC01(["UC-01 登录与学习档案"])
        UC02(["UC-02 创建/确认学习计划"])
        UC03(["UC-03 开放项目与里程碑"])
        UC04(["UC-04 获取/生成/推荐资源"])
        UC05(["UC-05 困难触发与分层支架"])
        UC06(["UC-06 阶段测试与作答"])
        UC07(["UC-07 查看学情与反思"])
        UC08(["UC-08 动态重规划"])
        UC09(["UC-09 查看历史/设置学伴"])
        UC10(["UC-10 班级总览与学生钻取"])
        UC11(["UC-11 复核干预/人工跟进"])
        UC12(["UC-12 审核资源与题目"])
        UC13(["UC-13 课程与知识库治理"])
        UC14(["UC-14 Agent、Prompt、Trigger 配置"])
        UC15(["UC-15 监控、权限与审计"])
    end

    STU --- UC01
    STU --- UC02
    STU --- UC03
    STU --- UC04
    STU --- UC05
    STU --- UC06
    STU --- UC07
    STU --- UC08
    STU --- UC09
    TEA --- UC10
    TEA --- UC11
    TEA --- UC12
    ADM --- UC13
    ADM --- UC14
    ADM --- UC15
    UC02 -.->|"可触发"| UC05
    UC06 -.->|"形成证据"| UC07
    UC07 -.->|"建议调整"| UC08
```

## 3. UML 组件图

![D-02 UML组件图](images/D-02_UML组件图.png)

### 3.1 组件职责

| 层级 | 核心组件 | 职责 |
|---|---|---|
| L1 交互层 | 学生工作区、教师工作台、管理治理台 | 输入、展示、确认、复核与配置 |
| L2 协调调控层 | 学伴、Harness、Trigger、状态机、确认服务 | 意图识别、上下文、路由、触发、状态约束、人机确认 |
| L3 能力层 | 六类功能 Agent、Tutor/Reflection Skills | 执行规划、资源、推荐、测试、评价、预测和支架任务 |
| L4 知识数据层 | 知识库、Student Model、计划/项目/事件/反思/日志 | 为 Agent 提供有权限边界的知识与学习证据 |
| L5 基础服务层 | 业务 API、关系库、向量检索、Model Router、权限监控 | 存储、检索、模型调用、鉴权、追踪和异常处理 |

### 3.2 Mermaid 源码

```mermaid
flowchart TB
    subgraph L1["L1 学生、教师、管理交互层"]
        SUI["学生工作区"]
        TUI["教师工作台"]
        AUI["管理治理台"]
    end

    subgraph L2["L2 智能体协调与调控层"]
        COMP["学伴智能体"]
        HAR["Education Harness"]
        TRG["Trigger Engine"]
        LSM["Learning State Machine"]
        CFM["Confirmation Service"]
    end

    subgraph L3["L3 智能体能力层"]
        PA["规划 Agent"]
        RA["资源 Agent"]
        REC["推荐 Agent"]
        TA["测试 Agent"]
        EA["评价 Agent"]
        PRA["预测 Agent"]
        SK["Tutor、Reflection 与公共 Skills"]
    end

    subgraph L4["L4 知识与数据层"]
        KB["课程、大纲、资源与题库"]
        SM["Student Model"]
        PT["计划、项目与任务"]
        EI["事件、干预、确认与反思"]
        LOG["运行与审计日志"]
    end

    subgraph L5["L5 基础服务层"]
        API["业务 API"]
        DB[("PostgreSQL 与向量检索")]
        MR["Model Router"]
        MODEL["L0 规则至 L3 强模型"]
        SEC["文件、权限与监控"]
    end

    SUI --> COMP --> HAR
    TUI --> API
    AUI --> API
    TRG --> HAR
    LSM --> TRG
    CFM --> COMP
    HAR --> PA
    HAR --> RA
    HAR --> REC
    HAR --> TA
    HAR --> EA
    HAR --> PRA
    HAR --> SK
    PA --> KB
    PA --> SM
    PA --> PT
    RA --> KB
    RA --> SM
    REC --> KB
    REC --> SM
    TA --> KB
    TA --> EI
    EA --> SM
    EA --> EI
    PRA --> SM
    PRA --> EI
    SK --> KB
    SK --> EI
    HAR --> MR --> MODEL
    KB --> DB
    SM --> DB
    PT --> DB
    EI --> DB
    LOG --> DB
    API --> HAR
    API --> DB
    API --> SEC
```

## 4. ER 图

![D-03 核心ER图](images/D-03_ER图.png)

### 4.1 ER 图说明

ER 图以学生、课程、项目、计划、任务、资源和测评为主数据骨架，并补入 V2.0 的事件、干预和确认链。图中只保留核心字段；完整实现还应增加 ProjectArtifact、Reflection、TeacherFollowUp、PlanVersion、ReviewRecord、AgentRunLog、ModelCallLog、PromptVersion 和 TriggerRule 等表。

### 4.2 Mermaid 源码

```mermaid
erDiagram
    STUDENT ||--o{ ENROLLMENT : "选修"
    COURSE ||--o{ ENROLLMENT : "包含学生"
    STUDENT ||--o{ PROJECT : "创建"
    PROJECT ||--o{ MILESTONE : "包含"
    STUDENT ||--o{ LEARNING_PLAN : "制订"
    COURSE ||--o{ LEARNING_PLAN : "对应"
    LEARNING_PLAN ||--o{ LEARNING_TASK : "分解"
    MILESTONE ||--o{ LEARNING_TASK : "关联"
    COURSE ||--o{ KNOWLEDGE_POINT : "包含"
    KNOWLEDGE_POINT }o--o{ RESOURCE : "对应"
    STUDENT ||--o{ RESOURCE_USE : "产生"
    RESOURCE ||--o{ RESOURCE_USE : "被使用"
    COURSE ||--o{ TEST : "包含"
    TEST ||--o{ TEST_ITEM : "组成"
    QUESTION ||--o{ TEST_ITEM : "被选入"
    STUDENT ||--o{ TEST_ATTEMPT : "参加"
    TEST ||--o{ TEST_ATTEMPT : "产生"
    TEST_ATTEMPT ||--o{ ANSWER_RECORD : "包含"
    QUESTION ||--o{ ANSWER_RECORD : "对应"
    STUDENT ||--o{ EVALUATION : "获得"
    STUDENT ||--o{ PREDICTION : "获得"
    STUDENT ||--o{ LEARNING_EVENT : "产生"
    LEARNING_EVENT ||--o| INTERVENTION : "触发"
    INTERVENTION ||--o| CONFIRMATION : "请求"

    STUDENT {
        string student_id
        string stage
        string profile_status
    }
    COURSE {
        string course_id
        string name
        string syllabus_version
    }
    PROJECT {
        string project_id
        string student_id
        string goal
        string status
    }
    LEARNING_PLAN {
        string plan_id
        string student_id
        string course_id
        string type
        string status
    }
    LEARNING_TASK {
        string task_id
        string plan_id
        string milestone_id
        datetime due_at
        string status
    }
    RESOURCE {
        string resource_id
        string course_id
        string type
        string source
        string review_status
    }
    TEST_ATTEMPT {
        string attempt_id
        string student_id
        string test_id
        decimal score
        datetime completed_at
    }
    EVALUATION {
        string evaluation_id
        string student_id
        string course_id
        string evidence_range
        string result_version
    }
    PREDICTION {
        string prediction_id
        string student_id
        string prediction_target
        string risk_level
        decimal confidence
    }
    LEARNING_EVENT {
        string event_id
        string student_id
        string event_type
        string state_before
        datetime event_time
    }
    INTERVENTION {
        string intervention_id
        string event_id
        string trigger_rule
        string action
        string effect_metric
    }
    CONFIRMATION {
        string confirmation_id
        string intervention_id
        string draft_version
        string response
        datetime responded_at
}
```

## 5. UML 类图

![D-04 UML类图](images/D-04_UML类图.png)

### 5.1 类图说明

- `LearningCompanion` 负责学生对话、结果整合和确认请求，不承担全部专业任务。
- `EducationHarness` 负责路由、上下文、权限、生命周期、结果校验与追踪。
- `TriggerEngine` 接收学习事件，在状态、规则、冷却期、置信度和偏好约束下决定静默或介入。
- `LearningStateMachine` 定义合法状态与主动行为资格。
- 六类 Agent 通过 `SkillRegistry`、`KnowledgeService` 和 `LearningDataService` 完成任务。
- `ModelRouter` 根据复杂度、风险、隐私、延迟和预算在 L0～L3 之间选择执行方式。

### 5.2 Mermaid 源码

```mermaid
classDiagram
    class LearningCompanion {
        -sessionId
        -currentContext
        +understandIntent()
        +presentResult()
        +requestConfirmation()
    }
    class EducationHarness {
        -agentRegistry
        -policy
        -traceContext
        +routeTask()
        +buildContext()
        +invoke()
        +validateResult()
    }
    class TriggerEngine {
        -rules
        -cooldowns
        -confidence
        +acceptEvent()
        +matchRule()
        +createIntervention()
        +staySilent()
    }
    class LearningStateMachine {
        -currentState
        -transitions
        +canTrigger()
        +transition()
        +allowedActions()
    }
    class ConfirmationService {
        -pendingDrafts
        -tokens
        +createDraft()
        +accept()
        +reject()
    }
    class StudentModelService {
        -knowledgeState
        -taskState
        -preferences
        +updateFromEvent()
        +estimateMastery()
        +getRiskFeatures()
        +updateSupportPolicy()
    }
    class ModelRouter {
        -routePolicy
        -budget
        +selectTier()
        +invokeModel()
        +failover()
    }
    class PlanningAgent {
        +createPlan()
        +replan()
    }
    class ResourceAgent {
        +generateResource()
    }
    class RecommendationAgent {
        +recommend()
    }
    class TestAgent {
        +buildTest()
        +grade()
    }
    class EvaluationAgent {
        +evaluate()
    }
    class PredictionAgent {
        +predictRisk()
    }
    class SkillRegistry {
        +resolve()
        +invoke()
    }
    class KnowledgeService {
        +search()
        +read()
        +publish()
    }
    class LearningDataService {
        +queryScope()
        +saveRecord()
    }

    LearningCompanion --> EducationHarness : 提交任务
    TriggerEngine --> EducationHarness : 触发请求
    LearningStateMachine --> TriggerEngine : 约束
    EducationHarness --> ModelRouter : 模型路由
    TriggerEngine --> ConfirmationService : 重大变更
    LearningStateMachine --> StudentModelService : 读取状态
    EducationHarness --> PlanningAgent
    EducationHarness --> ResourceAgent
    EducationHarness --> RecommendationAgent
    EducationHarness --> TestAgent
    EducationHarness --> EvaluationAgent
    EducationHarness --> PredictionAgent
    PlanningAgent --> SkillRegistry
    ResourceAgent --> KnowledgeService
    RecommendationAgent --> StudentModelService
    TestAgent --> KnowledgeService
    EvaluationAgent --> LearningDataService
    PredictionAgent --> LearningDataService
```

## 6. UML 学习状态图

![D-05 UML状态图](images/D-05_UML状态图.png)

### 6.1 Mermaid 源码

```mermaid
stateDiagram-v2
    state "未规划" as S0
    state "规划中" as S1
    state "待确认" as S2
    state "学习中" as S3
    state "检查点" as S4
    state "反思中" as S5
    state "需调整" as S6
    state "已完成" as S7

    [*] --> S0
    S0 --> S1: 建立档案或输入目标
    S1 --> S2: 生成计划草案
    S2 --> S3: 学生确认
    S2 --> S1: 学生修改
    S3 --> S4: 阶段任务完成 T05
    S4 --> S5: 提交测试并形成证据
    S5 --> S7: 目标达成
    S5 --> S3: 继续原计划
    S5 --> S6: 延期、薄弱点或时间变化
    S3 --> S6: T08 至 T10
    S6 --> S2: 生成调整草案
    S6 --> S3: 暂不调整
    S7 --> S0: 新目标
```

## 7. UI 页面原型

### 7.1 页面总表

| 页面编号 | 页面 | 主要角色 | 主要功能/用例 | 关键状态与操作 |
|---|---|---|---|---|
| UI-01 | 登录页 | 学生 | UC-01 | 身份认证、隐私说明、异常提示 |
| UI-02 | 主工作区 | 学生 | UC-02～UC-05、UC-09 | 今日任务、项目切换、学伴对话、状态摘要 |
| UI-03 | 学习计划与项目页 | 学生 | UC-02、UC-03、UC-08 | 里程碑、任务、检查点、计划确认和版本 |
| UI-04 | 课程与资源页 | 学生 | UC-04、UC-05 | 检索、推荐、生成标识、审核状态、使用反馈 |
| UI-05 | 测试与作答页 | 学生 | UC-05、UC-06 | 独立作答、提交、结果与解析 |
| UI-06 | 学情反馈与反思页 | 学生 | UC-07、UC-08 | 证据、知识/任务/投入、反思、策略选择 |
| UI-07 | 动态重规划确认页 | 学生 | UC-08 | 原因、调整前后、预期影响、接受/修改/拒绝 |
| UI-08 | 学习历史页 | 学生 | UC-09 | 对话、任务、资源、测试、评价、提醒与版本记录 |
| UI-09 | 学伴设置页 | 学生 | UC-09 | 形象、提醒频率、支架层级、字号与无障碍 |
| UI-10 | 教师班级总览页 | 教师 | UC-10 | 红黄绿状态、检查点完成率、知识点热力图 |
| UI-11 | 教师干预与内容复核页 | 教师 | UC-11、UC-12 | 干预证据链、人工跟进、资源/题目审核 |
| UI-12 | 管理治理台 | 管理员 | UC-13～UC-15 | 知识库、Agent/Prompt、Trigger、监控、权限审计 |

### 7.2 学生端

#### UI-01 登录页

![UI-01 登录页](images/ui/UI-01_登录页.png)

**页面输入**：身份认证信息。  
**页面输出**：登录结果、学生内部编号、登录/认证异常提示。  
**对应接口**：AUTH/UI 登录接口、学习档案读取接口。  
**跳转**：成功 → UI-02；失败 → 留在 UI-01。

#### UI-02 主工作区

![UI-02 主工作区](images/ui/UI-02_主工作区.png)

**布局**：左侧导航和项目列表；中部今日任务与对话结果卡；右侧进度、知识状态、风险和下一个检查点。  
**关键操作**：开始任务、继续对话、切换课程/项目、查看计划、停止生成。  
**对应接口**：消息发送/流式回复、任务路由、学习档案、学习行为记录。

#### UI-03 学习计划与开放项目页

![UI-03 学习计划与项目页](images/ui/UI-03_学习计划与项目页.png)

**核心对象**：Project → Milestone → LearningPlan → LearningTask → Checkpoint。  
**关键操作**：接受计划、修改计划、降低强度、调整截止时间。  
**保存规则**：草案只在学生确认后成为正式计划；每次修改生成 PlanVersion。

#### UI-04 课程与资源页

![UI-04 课程与资源页](images/ui/UI-04_课程与资源页.png)

**资源标识**：已有资源、推荐资源、智能体生成。  
**显示字段**：课程、知识点、难度、来源、推荐理由、建议顺序、审核状态。  
**关键规则**：已有且审核通过的资源优先；AI 生成草稿可以用于当前学习，但进入正式资源库前需要审核。

#### UI-05 测试与作答页

![UI-05 测试与作答页](images/ui/UI-05_测试与作答页.png)

**测试前**：目的、范围、数量、预计时间、要求。  
**测试中**：题目、作答区、顺序、提交；正式检查点不提供答案型帮助。  
**测试后**：得分、逐题结果、解析、知识点表现和补偿资源。

#### UI-06 学情反馈与反思页

![UI-06 学情反馈与反思页](images/ui/UI-06_学情反馈与反思页.png)

**评价维度**：知识掌握、任务完成、学习投入及课程定义的素养表现；各维度分别呈现，不强行合成总分。  
**反思输入**：困难位置、原因、自评、下一步策略。  
**不确定性**：证据不足时显示“当前数据不足，暂时无法判断”。

#### UI-07 动态重规划确认页

![UI-07 动态重规划确认页](images/ui/UI-07_动态重规划确认页.png)

**必须显示**：触发原因、证据、调整前后对比、预期影响。  
**操作**：接受调整、修改后接受、暂不调整。  
**规则**：只有接受后才写入新计划版本；拒绝进入偏好与冷却记录。

#### UI-08 学习历史页

![UI-08 学习历史页](images/ui/UI-08_学习历史页.png)

**记录范围**：对话、计划版本、任务、资源、测试、评价、预测、触发与干预。  
**筛选**：课程、时间、记录类型。

#### UI-09 学伴设置页

![UI-09 学伴设置页](images/ui/UI-09_学伴设置页.png)

**设置项**：形象/皮肤、提醒频率、默认支架层级、字号、色弱模式。  
**边界**：形象变化不影响知识能力、Agent 权限、数据范围和评价结果。

### 7.3 教师端与管理端

#### UI-10 教师班级总览页

![UI-10 教师班级总览页](images/ui/UI-10_教师班级总览页.png)

**目标**：定位需要关注的学生，而不是替代教师完成辅导。  
**组件**：红黄绿状态卡、检查点完成率、知识点热力图、需关注学生列表。

#### UI-11 教师干预与内容复核页

![UI-11 教师干预与内容复核页](images/ui/UI-11_教师干预与内容复核页.png)

**干预复核**：按“触发原因—动作—学生响应—后续效果”展示证据链。  
**内容审核**：通过/驳回 AI 资源或题目，并记录原因、审核者、时间和版本。  
**权限边界**：教师可提出建议、标记人工跟进，不直接改写学生正式计划。

#### UI-12 管理治理台

![UI-12 管理治理台](images/ui/UI-12_管理治理台.png)

**治理对象**：课程/知识库、Agent/Prompt、Trigger、Harness/模型、角色权限。  
**关键能力**：版本对比与回滚、规则阈值/冷却期/置信度配置、调用量与失败率、审计日志检索。

## 8. 各功能流对应的 UI 流

### F-01 首次进入与创建学习计划

![F-01 首次进入与创建计划](images/flows/F-01_首次进入与创建计划.png)

```mermaid
flowchart LR
    A["UI-01 身份认证与隐私说明"] --> B["UI-02 进入主工作区并选择课程"]
    B --> C["UI-02 输入目标或创建开放项目"]
    C --> D["UI-03 读取已有上下文并只补问高影响变量"]
    D --> E["UI-03 展示计划草案"]
    E -->|接受| F[保存正式计划并进入学习中]
    E -->|修改| D
    E -->|拒绝| B
```

**对应**：UC-01、UC-02、UC-03；T01～T04；Student、Project、Milestone、LearningPlan、LearningTask、Confirmation。

### F-02 今日任务与资源学习

![F-02 今日任务与资源学习](images/flows/F-02_今日任务与资源学习.png)

```mermaid
flowchart LR
    A["UI-02 查看按优先级排列的今日任务"] --> B["UI-02 开始任务"]
    B --> C["UI-04 推荐 Agent 检索知识库"]
    C --> D{"存在合适资源？"}
    D -->|是| E["UI-04 显示已有资源、推荐资源与理由"]
    D -->|否| F["资源 Agent 生成带来源标识的草稿"]
    F --> E
    E --> G["UI-04 学习、完成与反馈"]
    G --> H["记录 ResourceUse 与 LearningEvent"]
```

**对应**：UC-04；FR-04～FR-06；Resource、ResourceUse、Recommendation、LearningEvent。

### F-03 学习困难触发与分层帮助

![F-03 困难触发与分层支架](images/flows/F-03_困难触发与分层支架.png)

```mermaid
flowchart LR
    A["UI-05 或任务页：第一次错误"] --> B["正常反馈，不主动打断"]
    B --> C["同一知识点连续第二次错误"]
    C --> D{"状态、阈值、冷却和置信度是否允许？"}
    D -->|否| E["静默记录或继续观察"]
    D -->|是，T06| F["UI-02 一级提示与追问"]
    F --> G{"后续是否正确？"}
    G -->|是| H["返回任务并记录效果"]
    G -->|否| I["升级概念解释或分步支架"]
    I --> J["UI-05 继续作答"]
    J --> H
    C -->|错误达到 T07| K["UI-04 补偿资源"]
```

**对应**：UC-05；T06、T07、T11、T12；LearningEvent、Intervention、StudentResponse、EffectMetric。

### F-04 阶段检查点—评价—反思

![F-04 检查点评价与反思](images/flows/F-04_检查点评价与反思.png)

```mermaid
flowchart LR
    A["UI-02 阶段任务完成"] -->|T05| B["状态切换为检查点"]
    B --> C["UI-05 测试 Agent 生成短测"]
    C --> D["学生独立作答并提交"]
    D --> E["生成得分、错误分布与解析"]
    E --> F["评价 Agent 综合过程证据与结果证据"]
    F --> G["UI-06 更新知识、任务与投入评价"]
    G --> H["状态切换为反思中"]
    H --> I["UI-06 学生完成反思与策略选择"]
```

**对应**：UC-06、UC-07；Test、Question、Attempt、AnswerRecord、Evaluation、Reflection、KnowledgeState。

### F-05 动态重规划与学生确认

![F-05 动态重规划](images/flows/F-05_动态重规划.png)

```mermaid
flowchart LR
    A["延期、低表现或可用时间变化"] --> B{"触发规则与状态是否允许？"}
    B -->|否| C["继续观察"]
    B -->|T08 至 T10| D["切换为需调整"]
    D --> E["规划 Agent 生成调整草案"]
    E --> F["UI-07 显示原因、证据、变化和影响"]
    F --> G{"学生选择"}
    G -->|接受| H["UI-03 保存 PlanVersion"]
    G -->|修改后接受| E
    G -->|暂不调整| I["保持原计划并进入冷却期"]
    H --> J["UI-02 返回学习中"]
```

**对应**：UC-08；Prediction、Intervention、Confirmation、PlanVersion、TriggerRule。

### F-06 教师干预复核与内容审核

![F-06 教师干预与内容审核](images/flows/F-06_教师干预与内容审核.png)

```mermaid
flowchart LR
    A["UI-10 班级红黄绿总览"] --> B["选择需关注学生"]
    B --> C["UI-11 查看触发、动作、响应与效果"]
    C --> D{"是否需要人工介入？"}
    D -->|是| E["标记人工跟进并记录"]
    D -->|否| F["保留 AI 支持并继续观察"]
    C --> G["查看待审核资源或题目"]
    G --> H{"审核结果"}
    H -->|通过| I["发布正式版本至 UI-04"]
    H -->|驳回| J["记录原因并退回修改"]
```

**对应**：UC-10～UC-12；Evaluation、Intervention、TeacherFollowUp、ReviewRecord、Resource/Question Version。

### F-07 管理治理与运行监控

![F-07 管理治理与运行监控](images/flows/F-07_管理治理与运行监控.png)

```mermaid
flowchart LR
    A["UI-12 维护课程与知识库"] --> B["配置 Agent 与 Prompt 版本"]
    B --> C["配置 Trigger 阈值、冷却与确认规则"]
    C --> D["上线并监控 Harness 与模型"]
    D --> E{"是否出现异常或误触发？"}
    E -->|否| F["持续观察命中率与效果"]
    E -->|是| G["按任务、模型、Prompt 和规则版本追溯"]
    G --> H["调整配置并生成新版本"]
    H --> D
    D --> I["权限与审计复核"]
```

**对应**：UC-13～UC-15；AgentConfig、PromptVersion、TriggerRule、AgentRunLog、ModelCallLog、AuditLog。

## 9. 页面状态与组件规范

### 9.1 统一卡片结构

计划卡、资源卡、测试卡、评价卡和确认卡统一采用四段结构：

1. 标题区：类型标签、标题、当前状态。
2. 内容区：核心结果、证据或摘要。
3. 操作区：确认、修改、忽略、开始、查看依据等按钮。
4. 来源区：已有资源、AI 生成、教师审核、数据范围、版本信息。

### 9.2 统一状态色

| 状态 | 颜色 | 使用场景 |
|---|---|---|
| 正常/完成/已发布 | 绿色 | 已完成任务、掌握良好、审核通过 |
| 需注意/待确认 | 黄色 | 计划草案、阶段检查点、低置信度、待审核 |
| 风险/需调整/失败 | 红色 | 任务延期、连续错误、模型失败、需要人工跟进 |
| 执行中/当前项 | 蓝色或蓝绿色 | 当前任务、学习中、正在生成 |
| 未开始/静默/禁用 | 灰色 | 未开始任务、冷却期、不具备触发资格 |

### 9.3 必须保留的交互约束

- 不显示 Agent 的内部推理过程，只显示任务状态、结果、依据和下一步操作。
- 计划生成、正式计划修改和重大重规划必须提供明确确认入口。
- 正式检查点中关闭答案型帮助；测试结束后再显示解析。
- 推荐资源说明理由、知识点、难度、来源和是否由 AI 生成。
- 评价与预测显示证据范围、模型/规则版本和不确定性。
- 视觉或情感数据仅在明确授权后作为辅助证据，不直接决定成绩。
- 教师和管理员看到的数据遵循角色与班级范围，不暴露无关学生隐私。

## 10. 开发交付顺序

### P0：先打通闭环

UI-01 → UI-02 → UI-03 → UI-04 → UI-05 → UI-06 → UI-07，并完成 F-01～F-05。后台先实现学伴、Harness、规划/资源/推荐/测试 Agent、规则型 Trigger、状态机、确认服务和结构化日志。

### P1：补足治理与教师支持

实现 UI-10～UI-12 及 F-06、F-07；补充教师复核、知识库审核、Agent/Prompt/Trigger 版本管理、监控和权限审计。

### P2：数据充分后再升级

在连续学习数据、Q 矩阵和标注质量满足条件后，再逐步接入 BKT/DKT/AKT/SAKT、认知诊断、任务风险模型和可选的端侧视觉状态特征；不得以模拟模型结论替代真实证据。
